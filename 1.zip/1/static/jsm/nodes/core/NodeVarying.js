class NodeVarying {

	constructor( name, type ) {

		this.isNodeVarying = true;

		this.name = name;
		this.type = type;

	}

}

export default NodeVarying;
